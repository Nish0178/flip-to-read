// src/shared/storage.ts
var DEFAULT_SERVER_URL = "https://flip-to-read.onrender.com";
var DEFAULT_WEBSITE_URL = "https://flip-to-read-web.onrender.com";
function getWebsiteUrl(serverUrl) {
  if (serverUrl && (serverUrl.includes("localhost") || serverUrl.includes("127.0.0.1"))) {
    return serverUrl.replace(/\/+$/, "");
  }
  return DEFAULT_WEBSITE_URL;
}
var DEFAULT_SETTINGS = {
  serverUrl: DEFAULT_SERVER_URL,
  openAutomatically: false,
  rememberPosition: true,
  openInWebsite: false
};
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["settings"], (result) => {
      resolve({ ...DEFAULT_SETTINGS, ...result.settings || {} });
    });
  });
}
async function getRecentBooks() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["recent_books"], (result) => {
      resolve(result.recent_books || []);
    });
  });
}
async function saveRecentBook(book) {
  const list = await getRecentBooks();
  const filtered = list.filter((b) => b.id !== book.id);
  filtered.unshift(book);
  const trimmed = filtered.slice(0, 10);
  return new Promise((resolve) => {
    chrome.storage.local.set({ recent_books: trimmed }, () => resolve());
  });
}

// src/shared/api.ts
async function getServerUrl() {
  const settings = await getSettings();
  return (settings.serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, "");
}
async function convertOnlinePdf(pdfUrl) {
  const serverUrl = await getServerUrl();
  try {
    const res = await fetch(`${serverUrl}/api/upload-url`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ url: pdfUrl })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || `Online conversion failed with HTTP ${res.status}`);
    }
    return data;
  } catch (err) {
    if (err.message && err.message.includes("Failed to fetch")) {
      throw new Error(`Flip to Read server is unreachable at ${serverUrl}. Please verify the backend is running.`);
    }
    throw err;
  }
}

// src/background/service-worker.ts
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "open-pdf-flipbook",
    title: "Open PDF with Flip to Read",
    contexts: ["link"],
    targetUrlPatterns: ["*://*/*.pdf*", "*://*/*.PDF*"]
  });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "open-pdf-flipbook" && info.linkUrl) {
    const pdfUrl = info.linkUrl;
    try {
      if (tab?.id) {
        chrome.action.setBadgeText({ text: "\u23F3", tabId: tab.id });
        chrome.action.setBadgeBackgroundColor({ color: "#E76F51", tabId: tab.id });
      }
      const book = await convertOnlinePdf(pdfUrl);
      await saveRecentBook({
        id: book.id,
        title: book.title || "PDF Document",
        pages: book.pages || 1,
        lastPage: 1,
        sourceUrl: pdfUrl,
        timestamp: Date.now()
      });
      if (tab?.id) {
        chrome.action.setBadgeText({ text: "", tabId: tab.id });
      }
      const settings = await getSettings();
      let readerUrl = chrome.runtime.getURL(`reader/reader.html?id=${encodeURIComponent(book.id)}`);
      if (settings.openInWebsite) {
        const base = getWebsiteUrl(settings.serverUrl);
        readerUrl = `${base}/flipbook.html?id=${encodeURIComponent(book.id)}`;
      }
      chrome.tabs.create({ url: readerUrl });
    } catch (err) {
      if (tab?.id) {
        chrome.action.setBadgeText({ text: "ERR", tabId: tab.id });
        chrome.action.setBadgeBackgroundColor({ color: "#ef4444", tabId: tab.id });
        setTimeout(() => chrome.action.setBadgeText({ text: "", tabId: tab.id }), 4e3);
      }
      console.error("Context menu PDF conversion failed:", err);
    }
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === "OPEN_READER") {
    (async () => {
      const settings = await getSettings();
      let targetUrl = chrome.runtime.getURL(`reader/reader.html?id=${encodeURIComponent(message.id)}`);
      if (settings.openInWebsite) {
        const base = getWebsiteUrl(settings.serverUrl);
        targetUrl = `${base}/flipbook.html?id=${encodeURIComponent(message.id)}`;
      }
      chrome.tabs.create({ url: targetUrl });
      sendResponse({ success: true });
    })();
    return true;
  }
});
