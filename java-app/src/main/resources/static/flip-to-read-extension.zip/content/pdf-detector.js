// src/content/pdf-detector.ts
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request && request.type === "DETECT_PDF") {
    const result = detectPdfInDocument();
    sendResponse(result);
  }
  return true;
});
function detectPdfInDocument() {
  const currentUrl = window.location.href;
  if (isPdfUrl(currentUrl)) {
    return {
      isPdf: true,
      url: currentUrl,
      title: extractDocumentTitle(currentUrl),
      source: "url"
    };
  }
  if (document.contentType === "application/pdf") {
    return {
      isPdf: true,
      url: currentUrl,
      title: extractDocumentTitle(currentUrl),
      source: "content-type"
    };
  }
  const embed = document.querySelector('embed[type="application/pdf"], embed[src*=".pdf"]');
  if (embed && embed.src) {
    const absUrl = new URL(embed.src, window.location.href).href;
    return {
      isPdf: true,
      url: absUrl,
      title: extractDocumentTitle(absUrl),
      source: "embed"
    };
  }
  const obj = document.querySelector('object[type="application/pdf"], object[data*=".pdf"]');
  if (obj && obj.data) {
    const absUrl = new URL(obj.data, window.location.href).href;
    return {
      isPdf: true,
      url: absUrl,
      title: extractDocumentTitle(absUrl),
      source: "embed"
    };
  }
  const iframe = document.querySelector('iframe[src*=".pdf"]');
  if (iframe && iframe.src) {
    const absUrl = new URL(iframe.src, window.location.href).href;
    return {
      isPdf: true,
      url: absUrl,
      title: extractDocumentTitle(absUrl),
      source: "iframe"
    };
  }
  return {
    isPdf: false,
    url: "",
    title: "",
    source: "none"
  };
}
function isPdfUrl(url) {
  try {
    const parsed = new URL(url);
    const pathname = parsed.pathname.toLowerCase();
    return pathname.endsWith(".pdf") || pathname.includes(".pdf/") || parsed.search.toLowerCase().includes(".pdf");
  } catch (e) {
    return false;
  }
}
function extractDocumentTitle(url) {
  if (document.title && !document.title.toLowerCase().includes("pdf.js") && document.title.trim().length > 0) {
    return document.title.trim();
  }
  try {
    const parsed = new URL(url);
    const parts = parsed.pathname.split("/");
    const last = parts[parts.length - 1];
    if (last && last.toLowerCase().endsWith(".pdf")) {
      return decodeURIComponent(last.replace(/\.pdf$/i, "").replace(/[_-]/g, " "));
    }
  } catch (e) {
  }
  return "PDF Document";
}
