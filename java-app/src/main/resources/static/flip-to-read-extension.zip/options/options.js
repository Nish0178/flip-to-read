// src/shared/storage.ts
var DEFAULT_SETTINGS = {
  serverUrl: "http://localhost:8080",
  openAutomatically: false,
  rememberPosition: true,
  openInWebsite: false
};
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["settings"], (result) => {
      resolve({ ...DEFAULT_SETTINGS, ...result.settings || {} });
    });
  });
}
async function saveSettings(settings) {
  const current = await getSettings();
  const updated = { ...current, ...settings };
  return new Promise((resolve) => {
    chrome.storage.local.set({ settings: updated }, () => resolve());
  });
}
async function clearRecentBooks() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(["recent_books"], () => resolve());
  });
}

// src/options/options.ts
document.addEventListener("DOMContentLoaded", async () => {
  const serverUrlInput = document.getElementById("server-url");
  const toggleRememberPos = document.getElementById("toggle-remember-pos");
  const toggleOpenInWebsite = document.getElementById("toggle-open-in-website");
  const toggleAutoOpen = document.getElementById("toggle-auto-open");
  const btnSaveSettings = document.getElementById("btn-save-settings");
  const saveMsg = document.getElementById("save-msg");
  const btnClearHistory = document.getElementById("btn-clear-history");
  const btnOpenPlatform = document.getElementById("btn-open-platform");
  const settings = await getSettings();
  serverUrlInput.value = settings.serverUrl || "http://localhost:8080";
  if (btnOpenPlatform) {
    btnOpenPlatform.href = settings.serverUrl || "http://localhost:8080";
  }
  toggleRememberPos.checked = settings.rememberPosition ?? true;
  toggleOpenInWebsite.checked = settings.openInWebsite ?? false;
  toggleAutoOpen.checked = settings.openAutomatically ?? false;
  btnSaveSettings.addEventListener("click", async () => {
    let url = serverUrlInput.value.trim();
    if (!url)
      url = "http://localhost:8080";
    await saveSettings({
      serverUrl: url,
      rememberPosition: toggleRememberPos.checked,
      openInWebsite: toggleOpenInWebsite.checked,
      openAutomatically: toggleAutoOpen.checked
    });
    if (btnOpenPlatform) {
      btnOpenPlatform.href = url;
    }
    saveMsg.style.display = "inline";
    setTimeout(() => {
      saveMsg.style.display = "none";
    }, 3e3);
  });
  btnClearHistory.addEventListener("click", async () => {
    if (confirm("Are you sure you want to clear your local flipbook reading history?")) {
      await clearRecentBooks();
      alert("Local reading history cleared.");
    }
  });
});
