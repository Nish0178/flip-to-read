// src/shared/storage.ts
var DEFAULT_SERVER_URL = "https://flip-to-read.onrender.com";
var DEFAULT_WEBSITE_URL = "https://flip-to-read-web.onrender.com";
function getWebsiteUrl(serverUrl) {
  if (serverUrl && (serverUrl.includes("localhost") || serverUrl.includes("127.0.0.1"))) {
    return serverUrl.replace(/\/+$/, "");
  }
  return DEFAULT_WEBSITE_URL;
}
var DEFAULT_SETTINGS = {
  serverUrl: DEFAULT_SERVER_URL,
  openAutomatically: false,
  rememberPosition: true,
  openInWebsite: false
};
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["settings"], (result) => {
      resolve({ ...DEFAULT_SETTINGS, ...result.settings || {} });
    });
  });
}
async function saveSettings(settings) {
  const current = await getSettings();
  const updated = { ...current, ...settings };
  return new Promise((resolve) => {
    chrome.storage.local.set({ settings: updated }, () => resolve());
  });
}
async function clearRecentBooks() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(["recent_books"], () => resolve());
  });
}

// src/options/options.ts
document.addEventListener("DOMContentLoaded", async () => {
  const serverUrlInput = document.getElementById("server-url");
  const toggleRememberPos = document.getElementById("toggle-remember-pos");
  const toggleOpenInWebsite = document.getElementById("toggle-open-in-website");
  const toggleAutoOpen = document.getElementById("toggle-auto-open");
  const btnSaveSettings = document.getElementById("btn-save-settings");
  const saveMsg = document.getElementById("save-msg");
  const btnClearHistory = document.getElementById("btn-clear-history");
  const btnOpenPlatform = document.getElementById("btn-open-platform");
  const settings = await getSettings();
  serverUrlInput.value = settings.serverUrl || DEFAULT_SERVER_URL;
  if (btnOpenPlatform) {
    btnOpenPlatform.href = getWebsiteUrl(settings.serverUrl);
  }
  toggleRememberPos.checked = settings.rememberPosition ?? true;
  toggleOpenInWebsite.checked = settings.openInWebsite ?? false;
  toggleAutoOpen.checked = settings.openAutomatically ?? false;
  btnSaveSettings.addEventListener("click", async () => {
    let url = serverUrlInput.value.trim();
    if (!url)
      url = DEFAULT_SERVER_URL;
    await saveSettings({
      serverUrl: url,
      rememberPosition: toggleRememberPos.checked,
      openInWebsite: toggleOpenInWebsite.checked,
      openAutomatically: toggleAutoOpen.checked
    });
    if (btnOpenPlatform) {
      btnOpenPlatform.href = getWebsiteUrl(url);
    }
    saveMsg.style.display = "inline";
    setTimeout(() => {
      saveMsg.style.display = "none";
    }, 3e3);
  });
  btnClearHistory.addEventListener("click", async () => {
    if (confirm("Are you sure you want to clear your local flipbook reading history?")) {
      await clearRecentBooks();
      alert("Local reading history cleared.");
    }
  });
});
