// src/shared/storage.ts
var DEFAULT_SERVER_URL = "https://flip-to-read.onrender.com";
var DEFAULT_WEBSITE_URL = "https://flip-to-read-web.onrender.com";
function getWebsiteUrl(serverUrl) {
  if (serverUrl && (serverUrl.includes("localhost") || serverUrl.includes("127.0.0.1"))) {
    return serverUrl.replace(/\/+$/, "");
  }
  return DEFAULT_WEBSITE_URL;
}
var DEFAULT_SETTINGS = {
  serverUrl: DEFAULT_SERVER_URL,
  openAutomatically: false,
  rememberPosition: true,
  openInWebsite: false
};
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["settings"], (result) => {
      resolve({ ...DEFAULT_SETTINGS, ...result.settings || {} });
    });
  });
}
async function getRecentBooks() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["recent_books"], (result) => {
      resolve(result.recent_books || []);
    });
  });
}
async function saveRecentBook(book) {
  const list = await getRecentBooks();
  const filtered = list.filter((b) => b.id !== book.id);
  filtered.unshift(book);
  const trimmed = filtered.slice(0, 10);
  return new Promise((resolve) => {
    chrome.storage.local.set({ recent_books: trimmed }, () => resolve());
  });
}
async function clearRecentBooks() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(["recent_books"], () => resolve());
  });
}

// src/shared/api.ts
async function getServerUrl() {
  const settings = await getSettings();
  return (settings.serverUrl || DEFAULT_SERVER_URL).replace(/\/+$/, "");
}
async function uploadLocalPdf(file) {
  const serverUrl = await getServerUrl();
  const formData = new FormData();
  formData.append("file", file);
  try {
    const res = await fetch(`${serverUrl}/api/upload`, {
      method: "POST",
      body: formData
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || `Upload failed with HTTP ${res.status}`);
    }
    return data;
  } catch (err) {
    if (err.message && err.message.includes("Failed to fetch")) {
      throw new Error(`Flip to Read server is unreachable at ${serverUrl}. Please verify the backend is running.`);
    }
    throw err;
  }
}
async function convertOnlinePdf(pdfUrl) {
  const serverUrl = await getServerUrl();
  try {
    const res = await fetch(`${serverUrl}/api/upload-url`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ url: pdfUrl })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || `Online conversion failed with HTTP ${res.status}`);
    }
    return data;
  } catch (err) {
    if (err.message && err.message.includes("Failed to fetch")) {
      throw new Error(`Flip to Read server is unreachable at ${serverUrl}. Please verify the backend is running.`);
    }
    throw err;
  }
}

// src/popup/popup.ts
document.addEventListener("DOMContentLoaded", async () => {
  const detectorStateLoading = document.getElementById("detector-state-loading");
  const detectorStateFound = document.getElementById("detector-state-found");
  const detectorStateNone = document.getElementById("detector-state-none");
  const detectedTitle = document.getElementById("detected-title");
  const detectedUrl = document.getElementById("detected-url");
  const btnOpenFlipbook = document.getElementById("btn-open-flipbook");
  const btnReDetect = document.getElementById("btn-re-detect");
  const popupProgress = document.getElementById("popup-progress");
  const progressStatusText = document.getElementById("progress-status-text");
  const popupError = document.getElementById("popup-error");
  const popupErrorText = document.getElementById("popup-error-text");
  const btnUploadLocal = document.getElementById("btn-upload-local");
  const localFileInput = document.getElementById("local-file-input");
  const btnOpenWebsite = document.getElementById("btn-open-website");
  const btnOptions = document.getElementById("btn-options");
  const recentList = document.getElementById("recent-list");
  const btnClearRecent = document.getElementById("btn-clear-recent");
  let currentDetectedPdf = null;
  btnOptions.addEventListener("click", () => {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL("options/options.html"));
    }
  });
  btnOpenWebsite.addEventListener("click", async () => {
    const settings = await getSettings();
    const url = getWebsiteUrl(settings.serverUrl);
    chrome.tabs.create({ url });
  });
  btnReDetect.addEventListener("click", () => {
    runDetection();
  });
  await runDetection();
  await renderRecent();
  async function runDetection() {
    clearError();
    detectorStateLoading.style.display = "flex";
    detectorStateFound.style.display = "none";
    detectorStateNone.style.display = "none";
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id || !tab.url) {
        showNoPdfDetected();
        return;
      }
      const tabUrl = tab.url;
      if (tabUrl.toLowerCase().includes(".pdf")) {
        const title = tab.title && !tab.title.toLowerCase().includes("pdf.js") ? tab.title : extractPdfFilename(tabUrl);
        showDetectedPdf({
          isPdf: true,
          url: tabUrl,
          title,
          source: "url"
        });
        return;
      }
      try {
        const response = await new Promise((resolve) => {
          chrome.tabs.sendMessage(tab.id, { type: "DETECT_PDF" }, (res) => {
            if (chrome.runtime.lastError || !res) {
              resolve({ isPdf: false, url: "", title: "", source: "none" });
            } else {
              resolve(res);
            }
          });
        });
        if (response && response.isPdf) {
          showDetectedPdf(response);
          return;
        }
      } catch (ignored) {
      }
      showNoPdfDetected();
    } catch (e) {
      showNoPdfDetected();
    }
  }
  function showDetectedPdf(pdf) {
    currentDetectedPdf = pdf;
    detectedTitle.textContent = pdf.title || "PDF Document";
    detectedUrl.textContent = pdf.url;
    detectorStateLoading.style.display = "none";
    detectorStateFound.style.display = "flex";
    detectorStateNone.style.display = "none";
  }
  function showNoPdfDetected() {
    currentDetectedPdf = null;
    detectorStateLoading.style.display = "none";
    detectorStateFound.style.display = "none";
    detectorStateNone.style.display = "flex";
  }
  btnOpenFlipbook.addEventListener("click", async () => {
    if (!currentDetectedPdf || !currentDetectedPdf.url)
      return;
    clearError();
    showProgress("Converting online PDF...");
    btnOpenFlipbook.disabled = true;
    try {
      const book = await convertOnlinePdf(currentDetectedPdf.url);
      await saveRecentBook({
        id: book.id,
        title: book.title || currentDetectedPdf.title || "PDF Document",
        pages: book.pages || 1,
        lastPage: 1,
        sourceUrl: currentDetectedPdf.url,
        timestamp: Date.now()
      });
      hideProgress();
      btnOpenFlipbook.disabled = false;
      openReader(book.id, 1);
    } catch (err) {
      hideProgress();
      btnOpenFlipbook.disabled = false;
      showError(err.message || "Failed to convert online PDF.");
    }
  });
  btnUploadLocal.addEventListener("click", () => {
    localFileInput.click();
  });
  localFileInput.addEventListener("change", async () => {
    if (!localFileInput.files || !localFileInput.files[0])
      return;
    const file = localFileInput.files[0];
    if (!file.name.toLowerCase().endsWith(".pdf")) {
      showError("Please select a valid PDF file (.pdf).");
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      showError("PDF file is too large (max 50 MB).");
      return;
    }
    clearError();
    showProgress("Uploading local PDF...");
    btnUploadLocal.disabled = true;
    try {
      const book = await uploadLocalPdf(file);
      await saveRecentBook({
        id: book.id,
        title: book.title || file.name.replace(/\.[^/.]+$/, ""),
        pages: book.pages || 1,
        lastPage: 1,
        timestamp: Date.now()
      });
      hideProgress();
      btnUploadLocal.disabled = false;
      openReader(book.id, 1);
    } catch (err) {
      hideProgress();
      btnUploadLocal.disabled = false;
      showError(err.message || "Failed to upload local PDF.");
    }
  });
  async function renderRecent() {
    const list = await getRecentBooks();
    if (!list || list.length === 0) {
      recentList.innerHTML = '<div class="recent-empty">No recent books yet.</div>';
      btnClearRecent.style.display = "none";
      return;
    }
    btnClearRecent.style.display = "inline";
    recentList.innerHTML = list.map((b) => `
      <div class="recent-item" data-id="${b.id}" data-page="${b.lastPage || 1}">
        <div class="recent-item-info">
          <span class="recent-item-title" title="${escapeHtml(b.title)}">${escapeHtml(b.title)}</span>
          <span class="recent-item-page">Page ${b.lastPage || 1} / ${b.pages || 1}</span>
        </div>
        <span class="recent-item-btn">Continue &rsaquo;</span>
      </div>
    `).join("");
    recentList.querySelectorAll(".recent-item").forEach((el) => {
      el.addEventListener("click", () => {
        const id = el.getAttribute("data-id");
        const page = parseInt(el.getAttribute("data-page") || "1", 10);
        if (id)
          openReader(id, page);
      });
    });
  }
  btnClearRecent.addEventListener("click", async () => {
    await clearRecentBooks();
    renderRecent();
  });
  async function openReader(bookId, page = 1) {
    const settings = await getSettings();
    let url = chrome.runtime.getURL(`reader/reader.html?id=${encodeURIComponent(bookId)}&page=${page}`);
    if (settings.openInWebsite) {
      const base = getWebsiteUrl(settings.serverUrl);
      url = `${base}/flipbook.html?id=${encodeURIComponent(bookId)}&page=${page}`;
    }
    chrome.tabs.create({ url });
    window.close();
  }
  function showProgress(msg) {
    progressStatusText.textContent = msg;
    popupProgress.style.display = "flex";
  }
  function hideProgress() {
    popupProgress.style.display = "none";
  }
  function showError(msg) {
    popupErrorText.textContent = msg;
    popupError.style.display = "flex";
  }
  function clearError() {
    popupError.style.display = "none";
  }
  function extractPdfFilename(url) {
    try {
      const parsed = new URL(url);
      const parts = parsed.pathname.split("/");
      const last = parts[parts.length - 1];
      if (last)
        return decodeURIComponent(last.replace(/[_-]/g, " "));
    } catch (e) {
    }
    return "document.pdf";
  }
  function escapeHtml(str) {
    return (str || "").replace(/[&<>'"]/g, (tag) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "'": "&#39;",
      '"': "&quot;"
    })[tag] || tag);
  }
});
